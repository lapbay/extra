//
//  HttpRequest.h
//  milan
//
//  Created by Wu Chang on 11-10-6.
//  Copyright 2011年 Unique. All rights reserved.
//

#import "ASIHTTPRequest.h"

@interface APIRequest : ASIHTTPRequest

@property (retain, nonatomic) id realDelegate;

@end
